import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("products")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

export const listByCategory = query({
  args: { categoryId: v.id("categories") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("products")
      .withIndex("by_category", (q) => q.eq("categoryId", args.categoryId))
      .collect();
  },
});

export const create = mutation({
  args: { 
    name: v.string(), 
    price: v.number(), 
    categoryId: v.id("categories") 
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Verify category belongs to user
    const category = await ctx.db.get(args.categoryId);
    if (!category || category.userId !== userId) {
      throw new Error("Category not found");
    }

    // Check if product already exists in this category
    const existing = await ctx.db
      .query("products")
      .withIndex("by_category", (q) => q.eq("categoryId", args.categoryId))
      .filter((q) => q.eq(q.field("name"), args.name))
      .first();

    if (existing) {
      // Update existing product price
      await ctx.db.patch(existing._id, { price: args.price });
      return existing._id;
    }

    return await ctx.db.insert("products", {
      name: args.name,
      price: args.price,
      categoryId: args.categoryId,
      userId,
    });
  },
});

export const update = mutation({
  args: { 
    id: v.id("products"), 
    name: v.string(), 
    price: v.number() 
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== userId) {
      throw new Error("Product not found");
    }

    await ctx.db.patch(args.id, { 
      name: args.name, 
      price: args.price 
    });
  },
});

export const remove = mutation({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== userId) {
      throw new Error("Product not found");
    }

    await ctx.db.delete(args.id);
  },
});

export const importFromSpreadsheet = mutation({
  args: { 
    data: v.array(v.object({
      category: v.string(),
      name: v.string(),
      price: v.number(),
    }))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const results = [];

    for (const item of args.data) {
      try {
        // Find or create category
        let category = await ctx.db
          .query("categories")
          .withIndex("by_user", (q) => q.eq("userId", userId))
          .filter((q) => q.eq(q.field("name"), item.category))
          .first();

        if (!category) {
          const categoryId = await ctx.db.insert("categories", {
            name: item.category,
            userId,
          });
          category = await ctx.db.get(categoryId);
        }

        if (category) {
          // Create or update product
          const existing = await ctx.db
            .query("products")
            .withIndex("by_category", (q) => q.eq("categoryId", category._id))
            .filter((q) => q.eq(q.field("name"), item.name))
            .first();

          if (existing) {
            await ctx.db.patch(existing._id, { price: item.price });
            results.push({ success: true, item: item.name, action: "updated" });
          } else {
            await ctx.db.insert("products", {
              name: item.name,
              price: item.price,
              categoryId: category._id,
              userId,
            });
            results.push({ success: true, item: item.name, action: "created" });
          }
        }
      } catch (error) {
        results.push({ 
          success: false, 
          item: item.name, 
          error: error instanceof Error ? error.message : "Unknown error" 
        });
      }
    }

    return results;
  },
});
