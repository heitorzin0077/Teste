import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("customers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

export const search = query({
  args: { query: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const customers = await ctx.db
      .query("customers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const searchTerm = args.query.toLowerCase();
    return customers.filter(customer => 
      customer.name.toLowerCase().includes(searchTerm) ||
      customer.phone.includes(searchTerm)
    );
  },
});

export const create = mutation({
  args: { name: v.string(), phone: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if customer with this phone already exists
    const existing = await ctx.db
      .query("customers")
      .withIndex("by_phone", (q) => q.eq("phone", args.phone))
      .filter((q) => q.eq(q.field("userId"), userId))
      .first();

    if (existing) {
      // Update existing customer
      await ctx.db.patch(existing._id, { name: args.name });
      return existing._id;
    }

    return await ctx.db.insert("customers", {
      name: args.name,
      phone: args.phone,
      userId,
    });
  },
});

export const update = mutation({
  args: { id: v.id("customers"), name: v.string(), phone: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const customer = await ctx.db.get(args.id);
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found");
    }

    await ctx.db.patch(args.id, { 
      name: args.name, 
      phone: args.phone 
    });
  },
});

export const remove = mutation({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const customer = await ctx.db.get(args.id);
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found");
    }

    await ctx.db.delete(args.id);
  },
});

export const importFromVCF = mutation({
  args: { 
    contacts: v.array(v.object({
      name: v.string(),
      phone: v.string(),
    }))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const results = [];

    for (const contact of args.contacts) {
      try {
        const existing = await ctx.db
          .query("customers")
          .withIndex("by_phone", (q) => q.eq("phone", contact.phone))
          .filter((q) => q.eq(q.field("userId"), userId))
          .first();

        if (existing) {
          results.push({ 
            success: true, 
            contact: contact.name, 
            action: "skipped (duplicate)" 
          });
        } else {
          await ctx.db.insert("customers", {
            name: contact.name,
            phone: contact.phone,
            userId,
          });
          results.push({ 
            success: true, 
            contact: contact.name, 
            action: "imported" 
          });
        }
      } catch (error) {
        results.push({ 
          success: false, 
          contact: contact.name, 
          error: error instanceof Error ? error.message : "Unknown error" 
        });
      }
    }

    return results;
  },
});
