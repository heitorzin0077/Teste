import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

const DEFAULT_MESSAGE_TEMPLATE = `Olá {{NOME_CLIENTE}}! 

Aqui está o seu pedido:

{{ITENS_PEDIDO}}

Total: {{TOTAL_PEDIDO}}

Obrigado pela preferência!`;

const DEFAULT_COMPOSITE_MESSAGE_TEMPLATE = `Olá! 

Aqui estão os pedidos:

{{PEDIDOS_COMPOSTOS}}

Total geral: {{TOTAL_GERAL}}

Obrigado pela preferência!`;

export const get = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    let settings = await ctx.db
      .query("settings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!settings) {
      // Create default settings
      const settingsId = await ctx.db.insert("settings", {
        userId,
        messageTemplate: DEFAULT_MESSAGE_TEMPLATE,
        compositeMessageTemplate: DEFAULT_COMPOSITE_MESSAGE_TEMPLATE,
        emailFrequency: "manual",
      });
      settings = await ctx.db.get(settingsId);
    }

    return settings;
  },
});

export const updateMessageTemplate = mutation({
  args: { template: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let settings = await ctx.db
      .query("settings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!settings) {
      await ctx.db.insert("settings", {
        userId,
        messageTemplate: args.template,
        compositeMessageTemplate: DEFAULT_COMPOSITE_MESSAGE_TEMPLATE,
        emailFrequency: "manual",
      });
    } else {
      await ctx.db.patch(settings._id, { messageTemplate: args.template });
    }
  },
});

export const updateCompositeMessageTemplate = mutation({
  args: { template: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let settings = await ctx.db
      .query("settings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!settings) {
      await ctx.db.insert("settings", {
        userId,
        messageTemplate: DEFAULT_MESSAGE_TEMPLATE,
        compositeMessageTemplate: args.template,
        emailFrequency: "manual",
      });
    } else {
      await ctx.db.patch(settings._id, { compositeMessageTemplate: args.template });
    }
  },
});

export const updateEmailSettings = mutation({
  args: { 
    emailDestination: v.optional(v.string()),
    emailFrequency: v.union(
      v.literal("manual"),
      v.literal("daily"),
      v.literal("weekly"),
      v.literal("monthly"),
      v.literal("yearly")
    )
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let settings = await ctx.db
      .query("settings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!settings) {
      await ctx.db.insert("settings", {
        userId,
        messageTemplate: DEFAULT_MESSAGE_TEMPLATE,
        compositeMessageTemplate: DEFAULT_COMPOSITE_MESSAGE_TEMPLATE,
        emailDestination: args.emailDestination,
        emailFrequency: args.emailFrequency,
      });
    } else {
      await ctx.db.patch(settings._id, { 
        emailDestination: args.emailDestination,
        emailFrequency: args.emailFrequency 
      });
    }
  },
});

export const updateLastEmailSent = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let settings = await ctx.db
      .query("settings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (settings) {
      await ctx.db.patch(settings._id, { lastEmailSent: Date.now() });
    }
  },
});
