import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const orders = await ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    // Get customer details for each order
    const ordersWithCustomers = await Promise.all(
      orders.map(async (order) => {
        const customer = await ctx.db.get(order.customerId);
        return {
          ...order,
          customer,
        };
      })
    );

    return ordersWithCustomers;
  },
});

export const search = query({
  args: { query: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const orders = await ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    const ordersWithCustomers = await Promise.all(
      orders.map(async (order) => {
        const customer = await ctx.db.get(order.customerId);
        return {
          ...order,
          customer,
        };
      })
    );

    const searchTerm = args.query.toLowerCase();
    return ordersWithCustomers.filter(order => 
      order.customer?.name.toLowerCase().includes(searchTerm) ||
      order.customer?.phone.includes(searchTerm)
    );
  },
});

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    items: v.array(v.object({
      productId: v.id("products"),
      productName: v.string(),
      quantity: v.number(),
      price: v.number(),
      temporaryPrice: v.optional(v.number()),
    })),
    total: v.number(),
    paymentStatus: v.union(v.literal("PIX"), v.literal("DIN"), v.literal("NPG")),
    isComposite: v.optional(v.boolean()),
    compositeOrderId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Verify customer belongs to user
    const customer = await ctx.db.get(args.customerId);
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found");
    }

    return await ctx.db.insert("orders", {
      customerId: args.customerId,
      items: args.items,
      total: args.total,
      paymentStatus: args.paymentStatus,
      userId,
      isComposite: args.isComposite,
      compositeOrderId: args.compositeOrderId,
    });
  },
});

export const updatePaymentStatus = mutation({
  args: { 
    id: v.id("orders"), 
    paymentStatus: v.union(v.literal("PIX"), v.literal("DIN"), v.literal("NPG"))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const order = await ctx.db.get(args.id);
    if (!order || order.userId !== userId) {
      throw new Error("Order not found");
    }

    await ctx.db.patch(args.id, { paymentStatus: args.paymentStatus });
  },
});

export const getById = query({
  args: { id: v.id("orders") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const order = await ctx.db.get(args.id);
    if (!order || order.userId !== userId) {
      return null;
    }

    const customer = await ctx.db.get(order.customerId);
    return {
      ...order,
      customer,
    };
  },
});
