import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  categories: defineTable({
    name: v.string(),
    userId: v.id("users"),
  }).index("by_user", ["userId"]),

  products: defineTable({
    name: v.string(),
    price: v.number(),
    categoryId: v.id("categories"),
    userId: v.id("users"),
  }).index("by_category", ["categoryId"])
    .index("by_user", ["userId"]),

  customers: defineTable({
    name: v.string(),
    phone: v.string(),
    userId: v.id("users"),
  }).index("by_user", ["userId"])
    .index("by_phone", ["phone"]),

  orders: defineTable({
    customerId: v.id("customers"),
    items: v.array(v.object({
      productId: v.id("products"),
      productName: v.string(),
      quantity: v.number(),
      price: v.number(),
      temporaryPrice: v.optional(v.number()),
    })),
    total: v.number(),
    paymentStatus: v.union(v.literal("PIX"), v.literal("DIN"), v.literal("NPG")),
    userId: v.id("users"),
    isComposite: v.optional(v.boolean()),
    compositeOrderId: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_customer", ["customerId"]),

  settings: defineTable({
    userId: v.id("users"),
    messageTemplate: v.string(),
    compositeMessageTemplate: v.string(),
    emailDestination: v.optional(v.string()),
    emailFrequency: v.union(
      v.literal("manual"),
      v.literal("daily"),
      v.literal("weekly"),
      v.literal("monthly"),
      v.literal("yearly")
    ),
    lastEmailSent: v.optional(v.number()),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
