import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { Dashboard } from "./components/Dashboard";
import { ProductManagement } from "./components/ProductManagement";
import { CustomerManagement } from "./components/CustomerManagement";
import { OrderHistory } from "./components/OrderHistory";
import { Settings } from "./components/Settings";

export default function App() {
  return (
    <div className="min-h-screen flex bg-gray-50">
      <Toaster />
      <Authenticated>
        <MainApp />
      </Authenticated>
      <Unauthenticated>
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="w-full max-w-md mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Sistema de Pedidos</h1>
              <p className="text-xl text-gray-600">Faça login para começar</p>
            </div>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>
    </div>
  );
}

function MainApp() {
  const [currentPage, setCurrentPage] = useState("dashboard");
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex-1 flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">Sistema de Pedidos</h2>
          <p className="text-sm text-gray-600 mt-1">
            Olá, {loggedInUser?.email?.split('@')[0] || 'usuário'}!
          </p>
        </div>
        <nav className="mt-6">
          <div className="px-3">
            <button
              onClick={() => setCurrentPage("dashboard")}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium mb-1 ${
                currentPage === "dashboard"
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              📋 Novo Pedido
            </button>
            <button
              onClick={() => setCurrentPage("products")}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium mb-1 ${
                currentPage === "products"
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              📦 Produtos
            </button>
            <button
              onClick={() => setCurrentPage("customers")}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium mb-1 ${
                currentPage === "customers"
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              👥 Clientes
            </button>
            <button
              onClick={() => setCurrentPage("history")}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium mb-1 ${
                currentPage === "history"
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              📊 Histórico
            </button>
            <button
              onClick={() => setCurrentPage("settings")}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium mb-1 ${
                currentPage === "settings"
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              ⚙️ Configurações
            </button>
          </div>
        </nav>
        <div className="absolute bottom-4 left-4 right-4">
          <SignOutButton />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-900">
              {currentPage === "dashboard" && "Novo Pedido"}
              {currentPage === "products" && "Gerenciar Produtos"}
              {currentPage === "customers" && "Gerenciar Clientes"}
              {currentPage === "history" && "Histórico de Pedidos"}
              {currentPage === "settings" && "Configurações"}
            </h1>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto">
          {currentPage === "dashboard" && <Dashboard />}
          {currentPage === "products" && <ProductManagement />}
          {currentPage === "customers" && <CustomerManagement />}
          {currentPage === "history" && <OrderHistory />}
          {currentPage === "settings" && <Settings />}
        </main>
      </div>
    </>
  );
}
