import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

export function OrderHistory() {
  const orders = useQuery(api.orders.list) || [];
  const settings = useQuery(api.settings.get);
  
  const updatePaymentStatus = useMutation(api.orders.updatePaymentStatus);
  
  const [searchTerm, setSearchTerm] = useState("");

  const filteredOrders = searchTerm
    ? orders.filter(order =>
        order.customer?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer?.phone.includes(searchTerm)
      )
    : orders;

  const handlePaymentStatusChange = async (orderId: Id<"orders">, status: "PIX" | "DIN" | "NPG") => {
    try {
      await updatePaymentStatus({ id: orderId, paymentStatus: status });
      toast.success("Status de pagamento atualizado!");
    } catch (error) {
      toast.error("Erro ao atualizar status de pagamento");
    }
  };

  const generateWhatsAppMessage = (order: any) => {
    if (!settings || !order.customer) return "";

    let message = settings.messageTemplate;
    
    const itemsList = order.items.map((item: any) => 
      `${item.quantity}x ${item.productName} - R$ ${(item.temporaryPrice || item.price).toFixed(2)}`
    ).join('\n');

    message = message.replace('{{NOME_CLIENTE}}', order.customer.name);
    message = message.replace('{{ITENS_PEDIDO}}', itemsList);
    message = message.replace('{{TOTAL_PEDIDO}}', `R$ ${order.total.toFixed(2)}`);

    return encodeURIComponent(message);
  };

  const resendWhatsApp = (order: any) => {
    if (!order.customer) return;
    
    const message = generateWhatsAppMessage(order);
    const whatsappUrl = `https://wa.me/${order.customer.phone.replace(/\D/g, '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const exportHistory = () => {
    const csvContent = [
      "Data,Cliente,Telefone,Total,Status,Itens",
      ...filteredOrders.map(order => {
        const date = new Date(order._creationTime).toLocaleDateString('pt-BR');
        const items = order.items.map((item: any) => 
          `${item.quantity}x ${item.productName}`
        ).join('; ');
        
        return `${date},"${order.customer?.name}","${order.customer?.phone}",${order.total.toFixed(2)},${order.paymentStatus},"${items}"`;
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `historico_pedidos_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("Histórico exportado com sucesso!");
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "PIX": return "bg-green-100 text-green-800";
      case "DIN": return "bg-blue-100 text-blue-800";
      case "NPG": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPaymentStatusText = (status: string) => {
    switch (status) {
      case "PIX": return "PIX";
      case "DIN": return "Dinheiro";
      case "NPG": return "Não Pago";
      default: return status;
    }
  };

  const totalRevenue = filteredOrders
    .filter(order => order.paymentStatus !== "NPG")
    .reduce((sum, order) => sum + order.total, 0);

  const totalPending = filteredOrders
    .filter(order => order.paymentStatus === "NPG")
    .reduce((sum, order) => sum + order.total, 0);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-sm font-medium text-gray-500">Total de Pedidos</h3>
          <p className="text-2xl font-bold text-gray-900">{filteredOrders.length}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-sm font-medium text-gray-500">Receita Recebida</h3>
          <p className="text-2xl font-bold text-green-600">R$ {totalRevenue.toFixed(2)}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-sm font-medium text-gray-500">Pendente</h3>
          <p className="text-2xl font-bold text-red-600">R$ {totalPending.toFixed(2)}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Buscar por cliente ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={exportHistory}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            📊 Exportar CSV
          </button>
        </div>
      </div>

      {/* Orders List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">
            Histórico de Pedidos ({filteredOrders.length})
          </h3>
          
          {filteredOrders.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              {searchTerm ? "Nenhum pedido encontrado" : "Nenhum pedido registrado ainda"}
            </p>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map(order => (
                <div key={order._id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    {/* Order Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold text-lg">{order.customer?.name}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(order.paymentStatus)}`}>
                          {getPaymentStatusText(order.paymentStatus)}
                        </span>
                        {order.isComposite && (
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                            Composto
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 mb-2">{order.customer?.phone}</p>
                      <p className="text-sm text-gray-500 mb-3">
                        {new Date(order._creationTime).toLocaleDateString('pt-BR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                      
                      {/* Order Items */}
                      <div className="space-y-1 mb-3">
                        {order.items.map((item: any, index: number) => (
                          <div key={index} className="text-sm text-gray-700">
                            {item.quantity}x {item.productName} - R$ {(item.temporaryPrice || item.price).toFixed(2)}
                            {item.temporaryPrice && (
                              <span className="text-orange-600 ml-1">(preço temp.)</span>
                            )}
                          </div>
                        ))}
                      </div>
                      
                      <div className="font-semibold text-lg text-green-600">
                        Total: R$ {order.total.toFixed(2)}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 lg:items-end">
                      {/* Payment Status Buttons */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => handlePaymentStatusChange(order._id, "PIX")}
                          className={`px-3 py-1 rounded text-sm font-medium ${
                            order.paymentStatus === "PIX"
                              ? "bg-green-600 text-white"
                              : "bg-green-100 text-green-700 hover:bg-green-200"
                          }`}
                        >
                          PIX
                        </button>
                        <button
                          onClick={() => handlePaymentStatusChange(order._id, "DIN")}
                          className={`px-3 py-1 rounded text-sm font-medium ${
                            order.paymentStatus === "DIN"
                              ? "bg-blue-600 text-white"
                              : "bg-blue-100 text-blue-700 hover:bg-blue-200"
                          }`}
                        >
                          DIN
                        </button>
                        <button
                          onClick={() => handlePaymentStatusChange(order._id, "NPG")}
                          className={`px-3 py-1 rounded text-sm font-medium ${
                            order.paymentStatus === "NPG"
                              ? "bg-red-600 text-white"
                              : "bg-red-100 text-red-700 hover:bg-red-200"
                          }`}
                        >
                          NPG
                        </button>
                      </div>
                      
                      {/* WhatsApp Button */}
                      <button
                        onClick={() => resendWhatsApp(order)}
                        className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 text-sm"
                      >
                        📱 Reenviar WhatsApp
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
