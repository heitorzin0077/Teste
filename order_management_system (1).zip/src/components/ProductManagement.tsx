import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

export function ProductManagement() {
  const categories = useQuery(api.categories.list) || [];
  const products = useQuery(api.products.list) || [];
  
  const createCategory = useMutation(api.categories.create);
  const updateCategory = useMutation(api.categories.update);
  const removeCategory = useMutation(api.categories.remove);
  const createProduct = useMutation(api.products.create);
  const updateProduct = useMutation(api.products.update);
  const removeProduct = useMutation(api.products.remove);
  const importProducts = useMutation(api.products.importFromSpreadsheet);

  const [newCategoryName, setNewCategoryName] = useState("");
  const [editingCategory, setEditingCategory] = useState<{ id: Id<"categories">; name: string } | null>(null);
  const [newProduct, setNewProduct] = useState({ name: "", price: "", categoryId: "" });
  const [editingProduct, setEditingProduct] = useState<{ id: Id<"products">; name: string; price: string } | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    try {
      await createCategory({ name: newCategoryName.trim() });
      setNewCategoryName("");
      toast.success("Categoria criada com sucesso!");
    } catch (error) {
      toast.error("Erro ao criar categoria");
    }
  };

  const handleUpdateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;

    try {
      await updateCategory({ id: editingCategory.id, name: editingCategory.name });
      setEditingCategory(null);
      toast.success("Categoria atualizada com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar categoria");
    }
  };

  const handleRemoveCategory = async (id: Id<"categories">) => {
    if (!confirm("Tem certeza? Isso também removerá todos os produtos desta categoria.")) return;

    try {
      await removeCategory({ id });
      toast.success("Categoria removida com sucesso!");
    } catch (error) {
      toast.error("Erro ao remover categoria");
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name.trim() || !newProduct.price || !newProduct.categoryId) return;

    try {
      await createProduct({
        name: newProduct.name.trim(),
        price: parseFloat(newProduct.price),
        categoryId: newProduct.categoryId as Id<"categories">
      });
      setNewProduct({ name: "", price: "", categoryId: "" });
      toast.success("Produto criado com sucesso!");
    } catch (error) {
      toast.error("Erro ao criar produto");
    }
  };

  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    try {
      await updateProduct({
        id: editingProduct.id,
        name: editingProduct.name,
        price: parseFloat(editingProduct.price)
      });
      setEditingProduct(null);
      toast.success("Produto atualizado com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar produto");
    }
  };

  const handleRemoveProduct = async (id: Id<"products">) => {
    if (!confirm("Tem certeza que deseja remover este produto?")) return;

    try {
      await removeProduct({ id });
      toast.success("Produto removido com sucesso!");
    } catch (error) {
      toast.error("Erro ao remover produto");
    }
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        toast.error("Arquivo deve ter pelo menos uma linha de cabeçalho e uma linha de dados");
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      const categoryIndex = headers.findIndex(h => h.includes('categoria'));
      const nameIndex = headers.findIndex(h => h.includes('nome') || h.includes('produto'));
      const priceIndex = headers.findIndex(h => h.includes('preço') || h.includes('preco') || h.includes('valor'));

      if (categoryIndex === -1 || nameIndex === -1 || priceIndex === -1) {
        toast.error("Arquivo deve conter colunas: Categoria, Nome do Produto, Preço");
        return;
      }

      const data = lines.slice(1).map(line => {
        const values = line.split(',').map(v => v.trim());
        return {
          category: values[categoryIndex] || "",
          name: values[nameIndex] || "",
          price: parseFloat(values[priceIndex]?.replace(/[^\d.,]/g, '').replace(',', '.')) || 0
        };
      }).filter(item => item.category && item.name && item.price > 0);

      if (data.length === 0) {
        toast.error("Nenhum dado válido encontrado no arquivo");
        return;
      }

      const results = await importProducts({ data });
      const successful = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;

      toast.success(`Importação concluída: ${successful} produtos processados, ${failed} erros`);
      setShowImportModal(false);
    } catch (error) {
      toast.error("Erro ao processar arquivo");
    }

    event.target.value = "";
  };

  const getProductsByCategory = (categoryId: Id<"categories">) => {
    return products.filter(product => product.categoryId === categoryId);
  };

  return (
    <div className="space-y-8">
      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Importar Produtos</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-2">
                  Selecione um arquivo CSV com as colunas: Categoria, Nome do Produto, Preço
                </p>
                <input
                  type="file"
                  accept=".csv,.xlsx"
                  onChange={handleFileImport}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Categories Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Categorias</h2>
          <button
            onClick={() => setShowImportModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            📁 Importar Produtos
          </button>
        </div>

        {/* Add Category Form */}
        <form onSubmit={handleCreateCategory} className="mb-6">
          <div className="flex gap-3">
            <input
              type="text"
              placeholder="Nome da categoria"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Adicionar
            </button>
          </div>
        </form>

        {/* Categories List */}
        <div className="space-y-4">
          {categories.map(category => (
            <div key={category._id} className="border border-gray-200 rounded-lg">
              <div className="p-4 bg-gray-50 border-b border-gray-200">
                {editingCategory?.id === category._id ? (
                  <form onSubmit={handleUpdateCategory} className="flex gap-3">
                    <input
                      type="text"
                      value={editingCategory.name}
                      onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                      className="flex-1 px-3 py-1 border border-gray-300 rounded"
                    />
                    <button type="submit" className="px-3 py-1 bg-green-600 text-white rounded text-sm">
                      Salvar
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingCategory(null)}
                      className="px-3 py-1 bg-gray-500 text-white rounded text-sm"
                    >
                      Cancelar
                    </button>
                  </form>
                ) : (
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-lg">{category.name}</h3>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingCategory({ id: category._id, name: category.name })}
                        className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => handleRemoveCategory(category._id)}
                        className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Products in Category */}
              <div className="p-4">
                {/* Add Product Form */}
                <form onSubmit={handleCreateProduct} className="mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <input
                      type="text"
                      placeholder="Nome do produto"
                      value={newProduct.categoryId === category._id ? newProduct.name : ""}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value, categoryId: category._id })}
                      className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Preço"
                      value={newProduct.categoryId === category._id ? newProduct.price : ""}
                      onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value, categoryId: category._id })}
                      className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                    >
                      Adicionar Produto
                    </button>
                  </div>
                </form>

                {/* Products List */}
                <div className="space-y-2">
                  {getProductsByCategory(category._id).map(product => (
                    <div key={product._id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      {editingProduct?.id === product._id ? (
                        <form onSubmit={handleUpdateProduct} className="flex gap-3 flex-1">
                          <input
                            type="text"
                            value={editingProduct.name}
                            onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                            className="flex-1 px-3 py-1 border border-gray-300 rounded"
                          />
                          <input
                            type="number"
                            step="0.01"
                            value={editingProduct.price}
                            onChange={(e) => setEditingProduct({ ...editingProduct, price: e.target.value })}
                            className="w-24 px-3 py-1 border border-gray-300 rounded"
                          />
                          <button type="submit" className="px-3 py-1 bg-green-600 text-white rounded text-sm">
                            Salvar
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingProduct(null)}
                            className="px-3 py-1 bg-gray-500 text-white rounded text-sm"
                          >
                            Cancelar
                          </button>
                        </form>
                      ) : (
                        <>
                          <div className="flex-1">
                            <span className="font-medium">{product.name}</span>
                            <span className="ml-4 text-green-600 font-semibold">R$ {product.price.toFixed(2)}</span>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingProduct({ 
                                id: product._id, 
                                name: product.name, 
                                price: product.price.toString() 
                              })}
                              className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                            >
                              Editar
                            </button>
                            <button
                              onClick={() => handleRemoveProduct(product._id)}
                              className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                            >
                              Remover
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                  {getProductsByCategory(category._id).length === 0 && (
                    <p className="text-gray-500 text-center py-4">Nenhum produto nesta categoria</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {categories.length === 0 && (
          <p className="text-gray-500 text-center py-8">Nenhuma categoria criada ainda</p>
        )}
      </div>
    </div>
  );
}
