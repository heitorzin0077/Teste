import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

export function CustomerManagement() {
  const customers = useQuery(api.customers.list) || [];
  
  const createCustomer = useMutation(api.customers.create);
  const updateCustomer = useMutation(api.customers.update);
  const removeCustomer = useMutation(api.customers.remove);
  const importContacts = useMutation(api.customers.importFromVCF);

  const [newCustomer, setNewCustomer] = useState({ name: "", phone: "" });
  const [editingCustomer, setEditingCustomer] = useState<{ id: Id<"customers">; name: string; phone: string } | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showImportModal, setShowImportModal] = useState(false);

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm)
  );

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name.trim() || !newCustomer.phone.trim()) return;

    try {
      await createCustomer({
        name: newCustomer.name.trim(),
        phone: newCustomer.phone.trim()
      });
      setNewCustomer({ name: "", phone: "" });
      toast.success("Cliente criado com sucesso!");
    } catch (error) {
      toast.error("Erro ao criar cliente");
    }
  };

  const handleUpdateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;

    try {
      await updateCustomer({
        id: editingCustomer.id,
        name: editingCustomer.name,
        phone: editingCustomer.phone
      });
      setEditingCustomer(null);
      toast.success("Cliente atualizado com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar cliente");
    }
  };

  const handleRemoveCustomer = async (id: Id<"customers">) => {
    if (!confirm("Tem certeza que deseja remover este cliente?")) return;

    try {
      await removeCustomer({ id });
      toast.success("Cliente removido com sucesso!");
    } catch (error) {
      toast.error("Erro ao remover cliente");
    }
  };

  const handleVCFImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const contacts = parseVCF(text);
      
      if (contacts.length === 0) {
        toast.error("Nenhum contato válido encontrado no arquivo");
        return;
      }

      const results = await importContacts({ contacts });
      const successful = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;

      toast.success(`Importação concluída: ${successful} contatos processados, ${failed} duplicatas ignoradas`);
      setShowImportModal(false);
    } catch (error) {
      toast.error("Erro ao processar arquivo VCF");
    }

    event.target.value = "";
  };

  const parseVCF = (vcfContent: string) => {
    const contacts: Array<{ name: string; phone: string }> = [];
    const vcards = vcfContent.split('BEGIN:VCARD');
    
    for (const vcard of vcards) {
      if (!vcard.includes('END:VCARD')) continue;
      
      let name = '';
      let phone = '';
      
      const lines = vcard.split('\n');
      for (const line of lines) {
        if (line.startsWith('FN:')) {
          name = line.substring(3).trim();
        } else if (line.startsWith('TEL:') || line.includes('TEL;')) {
          const phoneMatch = line.match(/[\d\s\-\(\)\+]+/);
          if (phoneMatch) {
            phone = phoneMatch[0].replace(/\D/g, '');
          }
        }
      }
      
      if (name && phone && phone.length >= 10) {
        contacts.push({ name, phone });
      }
    }
    
    return contacts;
  };

  return (
    <div className="space-y-6">
      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Importar Contatos</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-2">
                  Selecione um arquivo .vcf exportado do seu celular
                </p>
                <input
                  type="file"
                  accept=".vcf"
                  onChange={handleVCFImport}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Gerenciar Clientes</h2>
          <button
            onClick={() => setShowImportModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            📱 Importar Contatos
          </button>
        </div>

        {/* Add Customer Form */}
        <form onSubmit={handleCreateCustomer} className="mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Nome do cliente"
              value={newCustomer.name}
              onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
              className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="tel"
              placeholder="Telefone (WhatsApp)"
              value={newCustomer.phone}
              onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
              className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Adicionar Cliente
            </button>
          </div>
        </form>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Buscar cliente por nome ou telefone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Customers List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">
            Clientes ({filteredCustomers.length})
          </h3>
          
          {filteredCustomers.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              {searchTerm ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado ainda"}
            </p>
          ) : (
            <div className="space-y-3">
              {filteredCustomers.map(customer => (
                <div key={customer._id} className="border border-gray-200 rounded-lg p-4">
                  {editingCustomer?.id === customer._id ? (
                    <form onSubmit={handleUpdateCustomer} className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <input
                          type="text"
                          value={editingCustomer.name}
                          onChange={(e) => setEditingCustomer({ ...editingCustomer, name: e.target.value })}
                          className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="tel"
                          value={editingCustomer.phone}
                          onChange={(e) => setEditingCustomer({ ...editingCustomer, phone: e.target.value })}
                          className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="flex gap-3">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                        >
                          Salvar
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCustomer(null)}
                          className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
                        >
                          Cancelar
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-semibold text-lg">{customer.name}</h4>
                        <p className="text-gray-600">{customer.phone}</p>
                        <p className="text-sm text-gray-500">
                          Cadastrado em {new Date(customer._creationTime).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            const whatsappUrl = `https://wa.me/${customer.phone.replace(/\D/g, '')}`;
                            window.open(whatsappUrl, '_blank');
                          }}
                          className="px-3 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 text-sm"
                        >
                          📱 WhatsApp
                        </button>
                        <button
                          onClick={() => setEditingCustomer({ 
                            id: customer._id, 
                            name: customer.name, 
                            phone: customer.phone 
                          })}
                          className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => handleRemoveCustomer(customer._id)}
                          className="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
