
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function Settings() {
  const settings = useQuery(api.settings.get);
  const orders = useQuery(api.orders.list) || [];
  
  const updateMessageTemplate = useMutation(api.settings.updateMessageTemplate);
  