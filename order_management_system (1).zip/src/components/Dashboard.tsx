import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

interface OrderItem {
  productId: Id<"products">;
  productName: string;
  quantity: number;
  price: number;
  temporaryPrice?: number;
}

interface TemporaryPrice {
  [productId: string]: number;
}

export function Dashboard() {
  const categories = useQuery(api.categories.list) || [];
  const products = useQuery(api.products.list) || [];
  const customers = useQuery(api.customers.list) || [];
  const settings = useQuery(api.settings.get);
  
  const createOrder = useMutation(api.orders.create);
  
  const [selectedCustomer, setSelectedCustomer] = useState<Id<"customers"> | null>(null);
  const [orderItems, setOrderItems] = useState<{ [productId: string]: number }>({});
  const [temporaryPrices, setTemporaryPrices] = useState<TemporaryPrice>({});
  const [customerSearch, setCustomerSearch] = useState("");
  const [isCompositeMode, setIsCompositeMode] = useState(false);
  const [compositeOrders, setCompositeOrders] = useState<Array<{
    customer: Id<"customers">;
    items: { [productId: string]: number };
    temporaryPrices: TemporaryPrice;
  }>>([]);

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
    customer.phone.includes(customerSearch)
  );

  const getProductsByCategory = (categoryId: Id<"categories">) => {
    return products.filter(product => product.categoryId === categoryId);
  };

  const updateQuantity = (productId: string, change: number) => {
    setOrderItems(prev => {
      const newQuantity = Math.max(0, (prev[productId] || 0) + change);
      if (newQuantity === 0) {
        const { [productId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [productId]: newQuantity };
    });
  };

  const setTemporaryPrice = (productId: string, price: number) => {
    setTemporaryPrices(prev => ({ ...prev, [productId]: price }));
  };

  const calculateTotal = () => {
    return Object.entries(orderItems).reduce((total, [productId, quantity]) => {
      const product = products.find(p => p._id === productId);
      if (!product) return total;
      
      const price = temporaryPrices[productId] || product.price;
      return total + (price * quantity);
    }, 0);
  };

  const clearOrder = () => {
    setOrderItems({});
    setTemporaryPrices({});
    setSelectedCustomer(null);
    setCustomerSearch("");
  };

  const addToComposite = () => {
    if (!selectedCustomer || Object.keys(orderItems).length === 0) {
      toast.error("Selecione um cliente e adicione produtos");
      return;
    }

    setCompositeOrders(prev => [...prev, {
      customer: selectedCustomer,
      items: { ...orderItems },
      temporaryPrices: { ...temporaryPrices }
    }]);

    clearOrder();
    toast.success("Pedido adicionado ao pedido composto");
  };

  const removeFromComposite = (index: number) => {
    setCompositeOrders(prev => prev.filter((_, i) => i !== index));
  };

  const generateWhatsAppMessage = (orderData: OrderItem[], customer: any, total: number) => {
    if (!settings) return "";

    let message = settings.messageTemplate;
    
    const itemsList = orderData.map(item => 
      `${item.quantity}x ${item.productName} - R$ ${(item.temporaryPrice || item.price).toFixed(2)}`
    ).join('\n');

    message = message.replace('{{NOME_CLIENTE}}', customer.name);
    message = message.replace('{{ITENS_PEDIDO}}', itemsList);
    message = message.replace('{{TOTAL_PEDIDO}}', `R$ ${total.toFixed(2)}`);

    return encodeURIComponent(message);
  };

  const generateCompositeWhatsAppMessage = () => {
    if (!settings || compositeOrders.length === 0) return "";

    let message = settings.compositeMessageTemplate;
    let totalGeneral = 0;
    
    const ordersList = compositeOrders.map((order, index) => {
      const customer = customers.find(c => c._id === order.customer);
      if (!customer) return "";

      const orderItems = Object.entries(order.items).map(([productId, quantity]) => {
        const product = products.find(p => p._id === productId);
        if (!product) return null;
        
        const price = order.temporaryPrices[productId] || product.price;
        totalGeneral += price * quantity;
        
        return `${quantity}x ${product.name} - R$ ${price.toFixed(2)}`;
      }).filter(Boolean).join('\n');

      return `Pedido ${index + 1} - ${customer.name}:\n${orderItems}`;
    }).join('\n\n');

    message = message.replace('{{PEDIDOS_COMPOSTOS}}', ordersList);
    message = message.replace('{{TOTAL_GERAL}}', `R$ ${totalGeneral.toFixed(2)}`);

    return encodeURIComponent(message);
  };

  const saveOrder = async () => {
    if (!selectedCustomer || Object.keys(orderItems).length === 0) {
      toast.error("Selecione um cliente e adicione produtos");
      return;
    }

    try {
      const orderData: OrderItem[] = Object.entries(orderItems).map(([productId, quantity]) => {
        const product = products.find(p => p._id === productId);
        if (!product) throw new Error("Produto não encontrado");
        
        return {
          productId: productId as Id<"products">,
          productName: product.name,
          quantity,
          price: product.price,
          temporaryPrice: temporaryPrices[productId]
        };
      });

      await createOrder({
        customerId: selectedCustomer,
        items: orderData,
        total: calculateTotal(),
        paymentStatus: "NPG"
      });

      toast.success("Pedido salvo com sucesso!");
      clearOrder();
    } catch (error) {
      toast.error("Erro ao salvar pedido");
    }
  };

  const saveCompositeOrder = async () => {
    if (compositeOrders.length === 0) {
      toast.error("Adicione pedidos ao pedido composto");
      return;
    }

    try {
      const compositeId = Date.now().toString();
      
      for (const order of compositeOrders) {
        const orderData: OrderItem[] = Object.entries(order.items).map(([productId, quantity]) => {
          const product = products.find(p => p._id === productId);
          if (!product) throw new Error("Produto não encontrado");
          
          return {
            productId: productId as Id<"products">,
            productName: product.name,
            quantity,
            price: product.price,
            temporaryPrice: order.temporaryPrices[productId]
          };
        });

        const total = Object.entries(order.items).reduce((sum, [productId, quantity]) => {
          const product = products.find(p => p._id === productId);
          if (!product) return sum;
          const price = order.temporaryPrices[productId] || product.price;
          return sum + (price * quantity);
        }, 0);

        await createOrder({
          customerId: order.customer,
          items: orderData,
          total,
          paymentStatus: "NPG",
          isComposite: true,
          compositeOrderId: compositeId
        });
      }

      toast.success("Pedido composto salvo com sucesso!");
      setCompositeOrders([]);
      setIsCompositeMode(false);
    } catch (error) {
      toast.error("Erro ao salvar pedido composto");
    }
  };

  const sendWhatsApp = () => {
    if (!selectedCustomer || Object.keys(orderItems).length === 0) {
      toast.error("Selecione um cliente e adicione produtos");
      return;
    }

    const customer = customers.find(c => c._id === selectedCustomer);
    if (!customer) return;

    const orderData: OrderItem[] = Object.entries(orderItems).map(([productId, quantity]) => {
      const product = products.find(p => p._id === productId);
      if (!product) throw new Error("Produto não encontrado");
      
      return {
        productId: productId as Id<"products">,
        productName: product.name,
        quantity,
        price: product.price,
        temporaryPrice: temporaryPrices[productId]
      };
    });

    const message = generateWhatsAppMessage(orderData, customer, calculateTotal());
    const whatsappUrl = `https://wa.me/${customer.phone.replace(/\D/g, '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const sendCompositeWhatsApp = () => {
    if (compositeOrders.length === 0) {
      toast.error("Adicione pedidos ao pedido composto");
      return;
    }

    const message = generateCompositeWhatsAppMessage();
    // For composite orders, we'll use the first customer's phone
    const firstCustomer = customers.find(c => c._id === compositeOrders[0].customer);
    if (!firstCustomer) return;

    const whatsappUrl = `https://wa.me/${firstCustomer.phone.replace(/\D/g, '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Customer Selection */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Selecionar Cliente</h3>
        <div className="flex gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Buscar cliente por nome ou telefone..."
              value={customerSearch}
              onChange={(e) => setCustomerSearch(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {customerSearch && (
              <div className="mt-2 max-h-40 overflow-y-auto border border-gray-200 rounded-md">
                {filteredCustomers.map(customer => (
                  <button
                    key={customer._id}
                    onClick={() => {
                      setSelectedCustomer(customer._id);
                      setCustomerSearch(customer.name);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-gray-100 border-b border-gray-100 last:border-b-0"
                  >
                    <div className="font-medium">{customer.name}</div>
                    <div className="text-sm text-gray-600">{customer.phone}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsCompositeMode(!isCompositeMode)}
              className={`px-4 py-2 rounded-md font-medium ${
                isCompositeMode
                  ? "bg-purple-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {isCompositeMode ? "Modo Composto Ativo" : "Ativar Modo Composto"}
            </button>
          </div>
        </div>
        {selectedCustomer && (
          <div className="mt-4 p-3 bg-blue-50 rounded-md">
            <div className="font-medium text-blue-900">
              Cliente selecionado: {customers.find(c => c._id === selectedCustomer)?.name}
            </div>
            <div className="text-sm text-blue-700">
              {customers.find(c => c._id === selectedCustomer)?.phone}
            </div>
          </div>
        )}
      </div>

      {/* Composite Orders Display */}
      {isCompositeMode && compositeOrders.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Pedidos Compostos</h3>
          <div className="space-y-4">
            {compositeOrders.map((order, index) => {
              const customer = customers.find(c => c._id === order.customer);
              const orderTotal = Object.entries(order.items).reduce((sum, [productId, quantity]) => {
                const product = products.find(p => p._id === productId);
                if (!product) return sum;
                const price = order.temporaryPrices[productId] || product.price;
                return sum + (price * quantity);
              }, 0);

              return (
                <div key={index} className="border border-gray-200 rounded-md p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-medium">{customer?.name}</div>
                      <div className="text-sm text-gray-600 mb-2">{customer?.phone}</div>
                      <div className="space-y-1">
                        {Object.entries(order.items).map(([productId, quantity]) => {
                          const product = products.find(p => p._id === productId);
                          if (!product) return null;
                          const price = order.temporaryPrices[productId] || product.price;
                          return (
                            <div key={productId} className="text-sm">
                              {quantity}x {product.name} - R$ {price.toFixed(2)}
                            </div>
                          );
                        })}
                      </div>
                      <div className="font-semibold mt-2">Total: R$ {orderTotal.toFixed(2)}</div>
                    </div>
                    <button
                      onClick={() => removeFromComposite(index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Products Grid */}
      <div className="space-y-6">
        {categories.map(category => {
          const categoryProducts = getProductsByCategory(category._id);
          if (categoryProducts.length === 0) return null;

          return (
            <div key={category._id} className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold mb-4">{category.name}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {categoryProducts.map(product => {
                  const quantity = orderItems[product._id] || 0;
                  const temporaryPrice = temporaryPrices[product._id];
                  const displayPrice = temporaryPrice || product.price;

                  return (
                    <div
                      key={product._id}
                      className={`border rounded-lg p-4 ${
                        quantity > 0 ? "border-blue-500 bg-blue-50" : "border-gray-200"
                      }`}
                    >
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-gray-600 mb-2">
                        R$ {displayPrice.toFixed(2)}
                        {temporaryPrice && (
                          <span className="text-orange-600 ml-1">(temp)</span>
                        )}
                      </div>
                      
                      {/* Temporary Price Input */}
                      <div className="mb-3">
                        <input
                          type="number"
                          step="0.01"
                          placeholder="Preço temporário"
                          value={temporaryPrice || ""}
                          onChange={(e) => {
                            const value = parseFloat(e.target.value);
                            if (isNaN(value) || e.target.value === "") {
                              const { [product._id]: _, ...rest } = temporaryPrices;
                              setTemporaryPrices(rest);
                            } else {
                              setTemporaryPrice(product._id, value);
                            }
                          }}
                          className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(product._id, -1)}
                            className="w-8 h-8 rounded-full bg-red-100 text-red-600 hover:bg-red-200 flex items-center justify-center"
                          >
                            -
                          </button>
                          <span className="w-8 text-center font-medium">{quantity}</span>
                          <button
                            onClick={() => updateQuantity(product._id, 1)}
                            className="w-8 h-8 rounded-full bg-green-100 text-green-600 hover:bg-green-200 flex items-center justify-center"
                          >
                            +
                          </button>
                        </div>
                        {quantity > 0 && (
                          <div className="text-sm font-medium text-blue-600">
                            R$ {(displayPrice * quantity).toFixed(2)}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Order Summary and Actions */}
      {(Object.keys(orderItems).length > 0 || compositeOrders.length > 0) && (
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">
              {isCompositeMode ? "Resumo do Pedido Atual" : "Resumo do Pedido"}
            </h3>
            <div className="text-2xl font-bold text-blue-600">
              R$ {calculateTotal().toFixed(2)}
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            {!isCompositeMode ? (
              <>
                <button
                  onClick={saveOrder}
                  className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium"
                >
                  💾 Salvar Pedido
                </button>
                <button
                  onClick={sendWhatsApp}
                  className="px-6 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 font-medium"
                >
                  📱 Enviar WhatsApp
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={addToComposite}
                  className="px-6 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 font-medium"
                >
                  ➕ Adicionar ao Composto
                </button>
                {compositeOrders.length > 0 && (
                  <>
                    <button
                      onClick={saveCompositeOrder}
                      className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium"
                    >
                      💾 Salvar Pedido Composto
                    </button>
                    <button
                      onClick={sendCompositeWhatsApp}
                      className="px-6 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 font-medium"
                    >
                      📱 Enviar WhatsApp Composto
                    </button>
                  </>
                )}
              </>
            )}
            <button
              onClick={clearOrder}
              className="px-6 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 font-medium"
            >
              🗑️ Limpar Pedido
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
